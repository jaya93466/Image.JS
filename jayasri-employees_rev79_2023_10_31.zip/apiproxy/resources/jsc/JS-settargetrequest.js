//  context.getVariable("request.content")
//i want to modify request content that is going to target
//i want to add address property to request content
//i want to read request content flow variable and assign to a js variable named request.Content
requestContent = context.getVariable("request.content");

//i want to convert js variable requestContent to js object requestObject
reqObject = JSON.parse(requestContent);
print(JSON.stringify(reqObject));
//i want to add address property to requestObject 
//i want to convert requestObject into string requestContent
reqObject.address = context.getVariable("formattedAddress");
print(JSON.stringify(reqObject));
delete(reqObject.latitude);
delete(reqObject.longitude);
//i want to assign string requestContent to flow variable request.Content
context.setVariable("request.content", JSON.stringify(reqObject));